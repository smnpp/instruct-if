/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import metier.modele.Eleve;
import metier.service.Service;
import dao.JpaUtil;
import dao.EleveDao;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 *
 * @author selghissas
 */
import metier.modele.Eleve;

public class Main {

    public static void main(String[] args) {

        JpaUtil.creerFabriquePersistance();

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Service service = new Service();

        try {
            Date date1 = sdf.parse("27/03/2011");
            Eleve eleve1 = new Eleve("Pascal", "Alice", "alice.pascal@free.fr", "123456", date1, 5);
            service.inscrireEleve(eleve1, "0691664J");

            Date date2 = sdf.parse("27/03/2011");
            Eleve eleve2 = new Eleve("Jean", "François", "jeanfrancois@free.fr", "987654", date2, 5);
            service.inscrireEleve(eleve2, "0691664J");

            Date date3 = sdf.parse("28/03/2011");
            Eleve eleve3 = new Eleve("Paul", "Paul", "pfrancois@free.fr", "123456", date3, 5);
            service.inscrireEleve(eleve3, "0691478G");
            
        } catch (ParseException e) {
            e.printStackTrace();
        }

        JpaUtil.fermerFabriquePersistance();
    }
}
