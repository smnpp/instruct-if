/*
 Le service métier va utiliser EleveDao pour persister les données et GeoNetApi pour obtenir les coordonnées GPS.
 */
package metier.service;

import com.google.maps.model.LatLng; //classe LatLng pour les coordonnées
import dao.EleveDao;
import dao.EtablissementDao;
import dao.JpaUtil;
import metier.modele.Eleve;
import metier.modele.Etablissement;
import util.GeoNetApi;
import util.Message;
import util.EducNetApi;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Comparator;

/**
 *
 * @author selghissas
 */
public class Service {

    public EleveDao eleveDao = new EleveDao();
    public EtablissementDao etablissementDao = new EtablissementDao();

    public Boolean inscrireEleve(Eleve eleve, String uai) {
        boolean success = false;
        try {
            JpaUtil.creerContextePersistance();

            EducNetApi api = new EducNetApi();
            if (api.getInformationCollege(uai) != null || api.getInformationLycee(uai) != null) {
                Etablissement etablissement = new Etablissement();
                if (EtablissementDao.trouverParId(uai) == null) {
                    
                    List<String> result;
                    if (eleve.getClasse() > 2) {
                        result = api.getInformationCollege(uai);
                    } else {
                        result = api.getInformationLycee(uai);
                    }
                    if (result != null) {
                        etablissement.setUai(result.get(0));
                        etablissement.setNomEtablissement(result.get(1));
                        etablissement.setSecteur(result.get(2));
                        etablissement.setCodeCommune(result.get(3));
                        etablissement.setNomCommune(result.get(4));
                        etablissement.setCodeDepartement(result.get(5));
                        etablissement.setDepartement(result.get(6));
                        etablissement.setAcademie(result.get(7));
                        etablissement.setIps(result.get(8));

                        JpaUtil.ouvrirTransaction();
                        etablissementDao.create(etablissement);
                        JpaUtil.validerTransaction();

                    }
                }
                else {
                    etablissement = EtablissementDao.trouverParId(uai);
                }
                eleve.setEtablissement(etablissement);
                JpaUtil.ouvrirTransaction();
                eleveDao.create(eleve); // Persister l'entité eleve
                JpaUtil.validerTransaction();
                success = true;

                // Envoi du mail de confirmation
                Message.envoyerMail("contact@instruct.if", eleve.getMail(), "Bienvenue sur le réseau Instruct'IF", "Bonjour "
                        + eleve.getPrenom() + ", Nous te confirmons ton inscription sur le réseau INSTRUCT'IF. Si tu as besoin d'un soutien pour tes"
                        + " leçons, ou tes devoirs, rends-toi sur notre site pour une mise en relation avec un intervenant.");
            }

        else {
                JpaUtil.annulerTransaction();

                // Envoi du mail d'infirmité
                Message.envoyerMail("contact@instruct.if", eleve.getMail(), "Échec de l'inscription sur le réseau Instruct'IF",
                        "Bonjour "
                        + eleve.getPrenom() + " ton inscription sur le réseau INSTRUCT'IF a malencontreusement échoué... Merci de recommencer "
                        + "ultérieurement.");

            }

    }
    catch (Exception e

    
        ) {
            e.printStackTrace();
        JpaUtil.annulerTransaction();

        // Envoi du mail d'infirmité
        Message.envoyerMail("contact@instruct.if", eleve.getMail(), "Échec de l'inscription sur le réseau Instruct'IF",
                "Bonjour "
                + eleve.getPrenom() + " ton inscription sur le réseau INSTRUCT'IF a malencontreusement échoué... Merci de recommencer ultérieurement.");
    }

    
        finally {
            JpaUtil.fermerContextePersistance();
    }
    return success ;
}

public Eleve authentifierEleveMail(String mail, String motDePasse) {
        JpaUtil.creerContextePersistance();
        Eleve eleve = eleveDao.trouverParMail(mail);
        JpaUtil.fermerContextePersistance();
        if (eleve != null && eleve.getMotDePasse().equals(motDePasse)) {
            return eleve;
        } else {
            return null;
        }
    }

    public Eleve trouverEleveParId(Long id) {
        JpaUtil.creerContextePersistance();
        Eleve eleve = eleveDao.trouverParId(id);
        JpaUtil.fermerContextePersistance();
        if (eleve != null && eleve.getId().equals(id)) {
            return eleve;
        } else {
            return null;
        }
    }

    public List<Eleve> consulterListeEleves() {
        JpaUtil.creerContextePersistance();
        List<Eleve> eleves = eleveDao.getAllEleves();
        JpaUtil.fermerContextePersistance();
        if (eleves != null) {
            eleves.sort(Comparator.comparing(Eleve::getNom).thenComparing(Eleve::getPrenom));
        }
        return eleves;
    }
}
